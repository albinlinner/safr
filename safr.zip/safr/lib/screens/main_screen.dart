import 'package:flutter/material.dart';
import 'package:safr/fragments/about_fragment.dart';
import 'package:safr/fragments/profile_fragment.dart';
import 'package:safr/fragments/upload_fragment.dart';
import 'package:safr/utils/session_manager.dart';

class MainScreen extends StatefulWidget {
  MainScreen(SessionManager sessionManager);

  @override
  State<StatefulWidget> createState() {
    return _MainState();
  }
}

class _MainState extends State<MainScreen> {
  int _selectedIndex = 0;
  List<Widget> _widgetsList = <Widget>[
    ProfileFragment(),
    UploadFragment(),
    AboutFragment()
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(child: _widgetsList[_selectedIndex]),
        bottomNavigationBar: BottomNavigationBar(
          showSelectedLabels: false,
          showUnselectedLabels: false,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.person_pin),
              title: Text("Profile"),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.camera_alt),
              title: Text("Upload"),
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.info), title: Text("About"))
          ],
          currentIndex: _selectedIndex,
          backgroundColor: Colors.white,
          selectedItemColor: Colors.black,
          unselectedItemColor: Color(0XFFD3D4ED),
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
        ));
  }
}

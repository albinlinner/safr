import 'dart:async';

import 'package:flutter/material.dart';
import 'package:safr/screens/login_screen.dart';
import 'package:safr/screens/main_screen.dart';
import 'package:safr/utils/session_manager.dart';

class SplashScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SplashScreenState();
  }
}

class SplashScreenState extends State<SplashScreen> {
  SessionManager _sessionManager = SessionManager();

  @override
  void initState() {
    loadData();
    _sessionManager.load();
    super.initState();
  }

  Future<Timer> loadData() async {
    return new Timer(Duration(seconds: 2), onDoneLoading);
  }

  onDoneLoading() async {
    if (_sessionManager.isLogin==true) {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => MainScreen(_sessionManager)));
    } else {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: Stack(children: <Widget>[
          Align(
            alignment: FractionalOffset.center,
            child: Container(
            alignment: Alignment.center,
            child: Text("SafR", style: TextStyle(color: Colors.black, fontSize: 40, fontWeight: FontWeight.w900),),
          ),),
          Align(alignment: FractionalOffset.bottomCenter,
          child: Container(
            padding: EdgeInsets.all(16),
            child: CircularProgressIndicator(),),)
        ],));
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:safr/styleguide/textstyles.dart';
import 'package:safr/utils/utils.dart';

import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return RegisterState();
  }
}

class RegisterState extends State<RegisterScreen> {
  var mName = TextEditingController();
  var mEmail = TextEditingController();
  var mPassword = TextEditingController();
  var mMobile = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Builder(
            builder: (context) => SafeArea(
                    child: Stack(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.all(24.0),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                        child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Image(
                              image: AssetImage("images/back.png"),
                              width: 24.0,
                            )),
                      ),
                    ),
                    Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                            padding: EdgeInsets.all(24.0),
                            margin: EdgeInsets.only(top: 64.0),
                            child: SingleChildScrollView(
                                child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: <Widget>[
                                Container(
                                    child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    Container(
                                      child: Text(
                                        "Register",
                                        style: splashName,
                                      ),
                                    ),
                                    Container(
                                        margin: EdgeInsets.only(top: 24.0),
                                        child: TextField(
                                          textCapitalization:
                                              TextCapitalization.words,
                                          controller: mName,
                                          decoration: InputDecoration(
                                              labelText: "Full Name"),
                                          showCursor: false,
                                        )),
                                    Container(
                                        margin: EdgeInsets.only(top: 8.0),
                                        child: TextField(
                                          inputFormatters: <TextInputFormatter>[
                                            WhitelistingTextInputFormatter
                                                .digitsOnly,
                                          ],
                                          keyboardType: TextInputType.number,
                                          controller: mMobile,
                                          decoration: InputDecoration(
                                              prefixText: "+46 ",
                                              labelText: "Mobile No."),
                                          showCursor: false,
                                        )),
                                    Container(
                                        margin: EdgeInsets.only(top: 8.0),
                                        child: TextField(
                                          controller: mEmail,
                                          decoration: InputDecoration(
                                              labelText: "Address"),
                                          showCursor: false,
                                        )),
                                    Container(
                                        margin: EdgeInsets.only(top: 8.0),
                                        child: TextField(
                                          controller: mEmail,
                                          decoration: InputDecoration(
                                              labelText: "Email"),
                                          showCursor: false,
                                        )),
                                    Container(
                                        margin: EdgeInsets.only(top: 8.0),
                                        child: TextField(
                                          controller: mPassword,
                                          obscureText: true,
                                          decoration: InputDecoration(
                                              labelText: "Password"),
                                          showCursor: false,
                                        )),
                                    Container(
                                      margin: EdgeInsets.only(top: 64.0),
                                      width: double.infinity,
                                      child: InkWell(
                                        onTap: () {
                                          validateInputs(context);
                                        },
                                        child: Container(
                                          width: double.infinity,
                                          alignment: Alignment.center,
                                          height: 56.0,
                                          decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(28.0)),
                                          child: Text(
                                            "Register",
                                            style: homeRegisterBtn,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 64),
                                      width: double.infinity,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Text(
                                            "Already have an account? ",
                                            style: loginBelowText,
                                          ),
                                          InkWell(
                                              onTap: () {
                                                Navigator.of(context).push(
                                                    MaterialPageRoute(
                                                        builder: (context) {
                                                  return LoginScreen();
                                                }));
                                              },
                                              child: Text(
                                                "Login",
                                                style: loginLink,
                                              ))
                                        ],
                                      ),
                                    )
                                  ],
                                ))
                              ],
                            )))),
                  ],
                ))));
  }

  String name, mobile, email, password;

  void validateInputs(BuildContext context) async {
    name = mName.text.trim();
    mobile = mMobile.text.trim();
    email = mEmail.text.toLowerCase();
    password = mPassword.text.trim();

    if (name.isEmpty) {
      showMessage("Please enter your name", context);
    } else if (mobile.length != 10) {
      showMessage("Please enter 10 digit mobile number", context);
    } else if (!validateEmail(email)) {
      showMessage("Please enter a valid email address", context);
    } else if (password.length < 5) {
      showMessage("Password length should be 5 or more...", context);
    } else {
      //proceedRegistration();
    }
  }

/*Future<void> proceedRegistration() async {
    showProgressDialog(context, "Processing your request...");

    Firestore.instance
        .collection("users")
        .document(email)
        .get()
        .then((snapshot) {
      Navigator.pop(context);
      if (!snapshot.exists) {
        showProgressDialog(context, "Creating an account...");
        snapshot.reference.setData({
          'name': name,
          'email': email,
          'mobile': mobile,
          'location': '',
          'password': password,
          'createdOn': DateTime.now().millisecondsSinceEpoch
        }).then((v) {
          Navigator.pop(context);
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => LoginScreen()));
        });
      } else {
        showMessage("Email already exists...", context);
      }
    });
  }*/
}

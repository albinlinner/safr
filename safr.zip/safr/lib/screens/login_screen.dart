import 'package:flutter/material.dart';
import 'package:safr/screens/register_screen.dart';
import 'package:safr/styleguide/textstyles.dart';
import 'package:safr/utils/session_manager.dart';
import 'package:safr/utils/utils.dart';

import 'main_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _LoginState();
  }
}


class _LoginState extends State<LoginScreen> {
  var mEmail = TextEditingController();
  var mPassword = TextEditingController();

  SessionManager _sessionManager = SessionManager();

  //var _sessionManager = SessionManager();

  @override
  Widget build(BuildContext context) {
    _sessionManager.load();

    return Scaffold(
        body: Builder(
            builder: (context) => SafeArea(
                    child: Stack(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.all(24.0),
                      child: InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Image(
                          image: AssetImage("images/back.png"),
                          width: 24.0,
                        ),
                      ),
                    ),
                    Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                            padding: EdgeInsets.all(24.0),
                            margin: EdgeInsets.only(top: 64.0),
                            child: SingleChildScrollView(
                                child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: <Widget>[
                                Container(
                                    child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    Container(
                                      child: Text(
                                        "Login",
                                        style: splashName,
                                      ),
                                    ),
                                    Container(
                                        margin: EdgeInsets.only(top: 24.0),
                                        child: TextField(
                                          controller: mEmail,
                                          decoration: InputDecoration(
                                              hintText: "Email",
                                              labelText: "Email"),
                                          showCursor: false,
                                        )),
                                    Container(
                                        margin: EdgeInsets.only(top: 8.0),
                                        child: TextField(
                                          controller: mPassword,
                                          obscureText: true,
                                          decoration: InputDecoration(
                                              hintText: "Password",
                                              labelText: "Password"),
                                          showCursor: false,
                                        )),
                                    Container(
                                      margin: EdgeInsets.only(top: 64.0),
                                      width: double.infinity,
                                      child: InkWell(
                                        onTap: () {
                                          //validateInputs(context);

                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      MainScreen(_sessionManager)));
                                        },
                                        child: Container(
                                          width: double.infinity,
                                          alignment: Alignment.center,
                                          height: 56.0,
                                          decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadius.circular(28.0)),
                                          child: Text(
                                            "Login",
                                            style: homeRegisterBtn,
                                          ),
                                        ),
                                      ),
                                    ),
                                    InkWell(
                                        onTap: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>MainScreen(_sessionManager)));
                                        },
                                        child: Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 8),
                                      child: Text(
                                        "Forgot your password?",
                                        style: loginLink,
                                      ),
                                    )),
                                    Container(
                                      margin: EdgeInsets.only(top: 64),
                                      width: double.infinity,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Text(
                                            "Don't have an account? ",
                                            style: loginBelowText,
                                          ),
                                          InkWell(
                                              onTap: () {
                                                Navigator.of(context).push(
                                                    MaterialPageRoute(
                                                        builder: (context) {
                                                  return RegisterScreen();
                                                }));
                                              },
                                              child: Text(
                                                "Register now",
                                                style: loginLink,
                                              ))
                                        ],
                                      ),
                                    )
                                  ],
                                ))
                              ],
                            )))),
                  ],
                ))));
  }

  String email, password;

  void validateInputs(BuildContext context) {
    email = mEmail.text.toLowerCase();
    password = mPassword.text.trim();

    if (!validateEmail(email)) {
      showMessage("Please enter a valid email address", context);
    } else if (password.length < 5) {
      showMessage("Password length should be 5 or more...", context);
    } else {
      //proceedLogin(context);
    }
  }

/* Future<void> proceedLogin(BuildContext context) async {
    showProgressDialog(context, "Getting account details...");

    Firestore.instance
        .collection("users")
        .document(email)
        .get()
        .then((snapshot) {
      if (snapshot.exists) {
        if (snapshot['password'] == password) {

          _sessionManager.createSession(
              snapshot['name'], snapshot['email'], snapshot['location'], snapshot['image']);
          Navigator.pop(context);
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                  builder: (context) => MainScreen(_sessionManager)),
              (Route<dynamic> route) => false);
        } else {
          showMessage("Email or password is incorrect", context);
          Navigator.pop(context);
        }
      } else {
        showMessage("Email or password is incorrect", context);
        Navigator.pop(context);
      }

    });
  }*/
}

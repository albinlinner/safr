import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:safr/styleguide/textstyles.dart';

class UploadFragment extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _UploadState();
  }
}

class _UploadState extends State<UploadFragment> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Container(
          width: double.infinity,
        ),
        Container(
          padding: EdgeInsets.only(left: 64, right: 64),
          child: Image(image: AssetImage("images/upload.png"), color: Colors.black,),
        ),
        Container(
          margin: EdgeInsets.only(top: 64.0, left: 32, right: 32),
          width: double.infinity,
          child: InkWell(
            onTap: () {
              //validateInputs(context);
            },
            child: Container(
              width: double.infinity,
              alignment: Alignment.center,
              height: 56.0,
              decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius:
                  BorderRadius.circular(28.0)),
              child: Text(
                "Take Photo",
                style: homeRegisterBtn,
              ),
            ),
          ),
        )
      ],
    );
  }
}

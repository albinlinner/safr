import 'package:flutter/material.dart';

class ProfileFragment extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ProfileState();
  }
}

class _ProfileState extends State<ProfileFragment> {
  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.white,
        child: Column(
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(top: 32),
              alignment: Alignment.center,
              height: 120,
              width: 120,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("images/dummy_profile.jpg"),
                      fit: BoxFit.cover),
                  shape: BoxShape.circle),
            ),
            Container(
              margin: EdgeInsets.only(top: 16),
              width: double.infinity,
              child: Text(
                "Albin Linner",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 8),
              child: Text(
                "SafR ID: 9283742",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 17,
                    fontWeight: FontWeight.w600),
              ),
            ),
            Container(
              height: 1,
              width: double.infinity,
              color: Colors.grey[300],
              margin: EdgeInsets.only(top: 16, bottom: 16),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(top: 16, left: 17, bottom: 4),
              child: Text(
                "Full Name",
                style: TextStyle(color: Colors.black),
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(left: 16, right: 16),
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey,
                  offset: Offset(0.0, 1),
                  blurRadius: 4,
                )
              ], color: Colors.white, borderRadius: BorderRadius.circular(8)),
              child: Text(
                "Albin Linner",
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(top: 16, left: 17, bottom: 4),
              child: Text(
                "Home Address",
                style: TextStyle(color: Colors.black),
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(left: 16, right: 16),
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey,
                  offset: Offset(0.0, 1),
                  blurRadius: 4,
                )
              ], color: Colors.white, borderRadius: BorderRadius.circular(8)),
              child: Text(
                "House#1, Street#1, Shadman Colony, Lahore, Punjab Pakistan",
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(top: 16, left: 17, bottom: 4),
              child: Text(
                "Mobile No.",
                style: TextStyle(color: Colors.black),
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(left: 16, right: 16),
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey,
                  offset: Offset(0.0, 1),
                  blurRadius: 4,
                )
              ], color: Colors.white, borderRadius: BorderRadius.circular(8)),
              child: Text(
                "+92 314 7777722",
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(top: 16, left: 17, bottom: 4),
              child: Text(
                "Email",
                style: TextStyle(color: Colors.black),
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(left: 16, right: 16),
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                  color: Colors.grey,
                  offset: Offset(0.0, 1),
                  blurRadius: 4,
                )
              ], color: Colors.white, borderRadius: BorderRadius.circular(8)),
              child: Text(
                "syedfarhanghazi@gmail.com",
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
              ),
            )
          ],
        ));
  }
}

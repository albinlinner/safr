import 'package:flutter/material.dart';
class AboutFragment extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _AboutState();
  }
}

class _AboutState extends State<AboutFragment>{
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 16, right: 16),
      child: Column(children: <Widget>[
      Container(child: Text("About Us"),),
      Container(child: Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ullamcorper elementum lacus vitae faucibus. Nunc vitae tristique massa. Sed cursus purus purus, id vehicula augue pellentesque eu. Nulla id tincidunt metus. Etiam fringilla interdum sem in ultricies. In nisi magna, eleifend et gravida non, facilisis nec odio. Suspendisse tempor magna purus, ornare auctor ipsum egestas at. Duis eu tempus nulla. Quisque in lectus lectus. In maximus quam eget enim porttitor, a pulvinar ex semper. Aenean elementum molestie placerat. Phasellus urna eros, tempor ut consectetur id, vehicula sed odio. Nullam facilisis mi tellus. Curabitur lorem ligula, porta nec viverra quis, condimentum ut urna. Morbi pellentesque pulvinar magna, eget sollicitudin orci mollis a."),)
    ],),);
  }
}
import 'dart:ui';

import 'package:flutter/material.dart';


TextStyle splashName = TextStyle(
    fontWeight: FontWeight.w600, color: Color(0XFF38404C), fontSize: 32);
TextStyle homeHeading = TextStyle(
    fontWeight: FontWeight.w600, color: Color(0XFF38404C), fontSize: 21);

TextStyle homeText = TextStyle(
    fontWeight: FontWeight.w400, color: Color(0XFF697689), fontSize: 15);

TextStyle homeRegisterBtn =
    TextStyle(fontWeight: FontWeight.w700, color: Colors.white, fontSize: 16);

TextStyle homeLoginBtn = TextStyle(
    fontWeight: FontWeight.w700, color: Color(0XFF737892), fontSize: 16);

TextStyle loginLink = TextStyle(
    color: Colors.black, fontWeight: FontWeight.w400, fontSize: 14);
TextStyle loginBelowText = TextStyle(
    color: Color(0XFFD3D4ED), fontWeight: FontWeight.w400, fontSize: 14);

TextStyle textFieldLabel = TextStyle(
    color: Color(0XFF929CAA), fontWeight: FontWeight.w400, fontSize: 15);


TextStyle loginPageName = TextStyle(color: Colors.black, fontSize: 20.0, fontWeight: FontWeight.w700);
TextStyle buttonText = TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.w700);
TextStyle buttonTextPrimary = TextStyle(color: Colors.black, fontSize: 15.0, fontWeight: FontWeight.w700);
TextStyle normalText = TextStyle(color: Color(0XFF566265), fontFamily: "OpenSans");
TextStyle smallText = TextStyle(color: Color(0XFF9AAAAE), fontSize: 12.0);
TextStyle boldText = TextStyle(color: Color(0XFF566265), fontWeight: FontWeight.w700);
TextStyle profileName = TextStyle(color: Color(0XFF566265), fontWeight: FontWeight.w700, fontSize: 17.0);
TextStyle amount = TextStyle(color: Colors.lightGreenAccent, fontWeight: FontWeight.w700, fontSize: 15.0);


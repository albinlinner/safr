import 'package:shared_preferences/shared_preferences.dart';

class SessionManager {
  SharedPreferences sharedPreferences;

  String _name = "NAME";
  String _image = "IMAGE";
  String _email = "EMAIL";
  String _id = "ID";
  String _login = "IS_LOGIN";

  load() async {
    sharedPreferences = await SharedPreferences.getInstance();
  }

  createSession(String id, String name, String img, String email) {
    sharedPreferences.setString(_id, id);
    sharedPreferences.setString(_name, name);
    sharedPreferences.setString(_image, img);
    sharedPreferences.setString(_email, email);
    sharedPreferences.setBool(_login, true);
  }

  bool get isLogin => sharedPreferences.getBool(_login);

  String get id => sharedPreferences.getString(_id);

  String get name => sharedPreferences.get(_name);

  String get email => sharedPreferences.get(_email);

  String get login => _login;

  String get image => sharedPreferences.get(_image);
}
